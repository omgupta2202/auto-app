
def subtract(num1, num2):
  """Subtracts two numbers.

  Args:
    num1: The first number.
    num2: The second number.

  Returns:
    The result of subtracting num2 from num1.
  """
  return num1 - num2
