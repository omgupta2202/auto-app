
def add(num1, num2):
  """
  This function adds two numbers.

  Args:
    num1: The first number.
    num2: The second number.

  Returns:
    The sum of the two numbers.
  """
  return num1 + num2
